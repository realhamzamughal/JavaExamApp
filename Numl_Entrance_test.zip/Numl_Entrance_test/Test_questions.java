package Numl_Entrance_test;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Test_questions extends JFrame implements ActionListener{
        JRadioButton opt1;
        JRadioButton opt2;
        JRadioButton opt3;
        JRadioButton opt4;
        ButtonGroup  options;
        JButton next_question;
        JButton submit;
        ImageIcon icon_3;
        JLabel  Numl_BSSE;
        JLabel qno;
        JLabel question;
        public static  int  count =0;
        public static int ans_given = 0;
        public static int score =0;
        String questions[][] = new String[10][5];
        String answers[][]   = new String[10][2];

    public Test_questions(){
            super("NUML Entrance Test");


// frame
// main frame funtion start here
            icon_3 = new ImageIcon(getClass().getResource("numl.jpg"));
            setIconImage(icon_3.getImage());
            icon_3 = new ImageIcon(getClass().getResource("NUMLBS-SE.png"));
            Numl_BSSE = new JLabel(icon_3);
            Numl_BSSE.setBounds(0,0,0,0);
            Numl_BSSE.setSize(1100,300);
            add(Numl_BSSE);


// questions
        questions[0][0] = " What is the unit of electrical resistance?";
        questions[0][1] = "Volt";
        questions[0][2] = "Ohm";
        questions[0][3] = "Ampere";
        questions[0][4] = " Coulomb";

        questions[1][0] = "Which law states that the force between two charges is directly proportional to the " +
          "product of the charges and inversely proportional to the square of the distance between them?";
        questions[1][1] = "Newton's First Law";
        questions[1][2] = "Faraday's Law";
        questions[1][3] = "Coulomb's Law";
        questions[1][4] = "Ohm's Law";

        questions[2][0] = "Which of the following is a vector quantity?";
        questions[2][1] = "Speed";
        questions[2][2] = "Distance";
        questions[2][3] = "Work";
        questions[2][4] = "Velocity";

        questions[3][0] = "What is the value of square root of 8649";
        questions[3][1] = "98";
        questions[3][2] = "72";
        questions[3][3] = "93";
        questions[3][4] = "87";

        questions[4][0] = "17x-34=51 solve the expression for value of x? ";
        questions[4][1] = "5";
        questions[4][2] = "3";
        questions[4][3] = "-5";
        questions[4][4] = "4";

        questions[5][0] = "Which of the following is a marker interface?";
        questions[5][1] = "Runnable interface";
        questions[5][2] = "Remote interface";
        questions[5][3] = "Readable interface";
        questions[5][4] = "Result interface";

        questions[6][0] = "If the radius of a circle is doubled, how does the area change?";
        questions[6][1] = "It remains the same";
        questions[6][2] = "It doubles";
        questions[6][3] = "It triples";
        questions[6][4] = "It quadruples";

        questions[7][0] = "Which of the following elements is a noble gas?";
        questions[7][1] = "Hydrogen";
        questions[7][2] = "Nitrogen";
        questions[7][3] = "Oxygen";
        questions[7][4] = "Argon";

        questions[8][0] = "What is the chemical formula for water?";
        questions[8][1] = "H2O";
        questions[8][2] = "H2O2";
        questions[8][3] = " O2";
        questions[8][4] = "HO";

        questions[9][0] = " In the periodic table, elements in the same group have";
        questions[9][1] = "The same atomic number";
        questions[9][2] = "Similar chemical properties";
        questions[9][3] = "The same atomic mass";
        questions[9][4] = "The same number of neutrons";
            answers[0][1] = "Ohm";
            answers[1][1] = "Coulomb's Law";
            answers[2][1] = "Velocity";
            answers[3][1] = "93";
            answers[4][1] = "5";
            answers[5][1] = "readable interface";
            answers[6][1] = "It quadruples";
            answers[7][1] = "Argon";
            answers[8][1] = "H2O";
            answers[9][1] = "Similar chemical properties";
// labels for questions and numbers
            qno   = new JLabel("1");
            qno.setFont(new Font("Arial",Font.BOLD,20));
            qno.setBounds(100,280,780,100);
            qno.setSize(600,100);
            add(qno);
            question   = new JLabel(" question");
            question.setFont(new Font("Arial",Font.BOLD,20));
            question.setBounds(140,280,780,100);
            question.setSize(600,100);
            add(question);
// radio buttons

            opt1 = new JRadioButton();
            opt1.setBounds(100, 410, 700, 30);
            opt1.setBackground(Color.WHITE);
            opt1.setFont(new Font("Dialog", Font.PLAIN, 20));
            add(opt1);

            opt2 = new JRadioButton("option2");
            opt2.setBounds(100, 460, 700, 30);
            opt2.setBackground(Color.WHITE);
            opt2.setFont(new Font("Dialog", Font.PLAIN, 20));
            add(opt2);

            opt3 = new JRadioButton();
            opt3.setBounds(100, 500, 800, 50);
            opt3.setBackground(Color.WHITE);
            opt3.setFont(new Font("Dialog", Font.PLAIN, 20));
            add(opt3);

            opt4 = new JRadioButton("option4");
            opt4.setBounds(100, 560, 700, 30);
            opt4.setBackground(Color.WHITE);
            opt4.setFont(new Font("Dialog", Font.PLAIN, 20));
            add(opt4);
            options = new ButtonGroup();
            options.add(opt1);
            options.add(opt2);
            options.add(opt3);
            options.add(opt4);
           // next and submit button
            next_question = new JButton("NEXT");
            next_question.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
            next_question.setBounds(850, 450, 100, 50);
            next_question.setForeground(new Color (255, 255, 255));
            next_question.setBackground(new Color (50, 21, 152));
            //next_page.addActionListener(this);
            next_question.addActionListener(this);
            //next_question.setEnabled(false);
            add(next_question);

            submit = new JButton("SUBMIT");
            submit.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
            submit.setBounds(850, 550, 100, 50);
            submit.setForeground(new Color (255, 255, 255));
            submit.setBackground(new Color (50, 21, 152));
            //next_page.addActionListener(this);
            submit.addActionListener(this);
            submit.setEnabled(false);
            add(submit);
            // frame funtions
            setLayout(null);
            getContentPane().setBackground(new Color(255,255,255));
            setSize(1100,800);
            setLocation(300,100);
            start(count);

            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);

    }
// go
public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next_question) {
                repaint();
                opt1.setEnabled(true);
                opt2.setEnabled(true);
                opt3.setEnabled(true);
                opt4.setEnabled(true);

                ans_given = 1;
                if (options.getSelection() == null) {
                        answers[count][0] = "";
                } else {
                        answers[count][0] = options.getSelection().getActionCommand();
                }

                if (count == 8) {
                        next_question.setEnabled(false);
                        submit.setEnabled(true);
                }

                count++;
                start(count);
        }

        else if (ae.getSource() == submit)

        {
                ans_given = 1;
                if (options.getSelection() == null) {
                        answers[count][0] = "";
                } else
                {
                        answers[count][0] = options.getSelection().getActionCommand();
                }
                for (int i = 0; i < answers.length; i++) {
                        if (answers[i][0].equals(answers[i][1])) {
                                score += 10;
                        } else {
                                score += 0;
                        }
                }

                setVisible(false);

                new score(score);


        }

}

    public void start(int count) {
            qno.setText("" + (count + 1) + ". ");
            question.setText(questions[count][0]);
            opt1.setText(questions[count][1]);
            opt1.setActionCommand(questions[count][1]);

            opt2.setText(questions[count][2]);
            opt2.setActionCommand(questions[count][2]);

            opt3.setText(questions[count][3]);
            opt3.setActionCommand(questions[count][3]);

            opt4.setText(questions[count][4]);
            opt4.setActionCommand(questions[count][4]);

            options.clearSelection();
    }
    public static void main(String[] args) {
       new Test_questions();
    }
}

