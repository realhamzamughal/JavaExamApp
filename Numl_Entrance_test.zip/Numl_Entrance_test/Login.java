package Numl_Entrance_test;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame implements ActionListener {
    ImageIcon icon_2;
    public String Username;
    ImageIcon icon_3;
    JLabel Numl_BSSE;
    JLabel Major_sub;
    JLabel name;
    JLabel id;
    JTextField username;
    JTextField rollno;
    JButton next_page;
    JComboBox<String> combo;
    JButton perv_page;
    public Login() {


             super("NUML Entrance Test");// main frame funtion start here
             icon_2 = new ImageIcon(getClass().getResource("numl.jpg"));
             setIconImage(icon_2.getImage());
             // numl ENTRANCE TEST FRAME on frame
             icon_3 = new ImageIcon(getClass().getResource("NUMLBS-SE.png"));
             Numl_BSSE = new JLabel(icon_3);
             Numl_BSSE.setBounds(0,0,0,0);
             Numl_BSSE.setSize(1100,300);
             add(Numl_BSSE);
             //label for subjects
             Major_sub =  new JLabel("Select subjects");
             Major_sub.setFont(new Font ("Times New Roman",Font.BOLD,26));
             Major_sub.setBounds(700,300,500,100);
             add(Major_sub);
             // name and id label and text fields
       name = new JLabel("Enter Username");
       Username = name.getText();
        name.setFont(new Font("Times New Roman",Font.BOLD,26));
        name.setForeground(new Color(50, 32, 123));
        name.setBounds(100,320,56,100);
        name.setSize(600,100);
        add(name);
        id = new JLabel("Enter Rollno/ID");
        id.setFont(new Font("Times New Roman",Font.BOLD,26));
        id.setForeground(new Color(50, 32, 123));
        id.setBounds(100,390,56,100);
        id.setSize(600,100);
        add(id);

        username = new JTextField();
        username.setFont(new Font("Times New Roman",Font.BOLD,20));
        username.setForeground(new Color(2, 1, 11));
        username.setBounds(320,350,56,100);
        username.setSize(200,40);
        add(username);
        rollno = new JTextField();
        rollno.setFont(new Font("Times New Roman",Font.BOLD,20));
        rollno.setForeground(new Color(2, 1, 11));
        rollno.setBounds(320,420,56,100);
        rollno.setSize(200,40);
        add(rollno);
             // combo box for subject selection
             combo = new JComboBox<>();
             combo.addItem("  Math,physics,chemistry");
             combo.addItem("  Math,physics,Computer");
             combo.addItem("  Biology,physics,chemistry");
             combo.setBackground(new Color(57, 147, 196));
             combo.setForeground(Color.WHITE);
             combo.setFont(new Font("Times New Roman",Font.BOLD,16));
             combo.setBounds(700,380,250,50);
             add(combo);
             // button
        next_page = new JButton("SUBMIT");
        next_page.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        next_page.setBounds(850, 660, 100, 50);
        next_page.setForeground(new Color (255, 255, 255));
        next_page.setBackground(new Color (50, 21, 152));
        next_page.addActionListener(this);
        add(next_page);

        // previous page
        perv_page = new JButton("BACK");
        perv_page.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        perv_page.setBounds(70, 660, 100, 50);
        perv_page.setForeground(new Color (255, 255, 255));
        perv_page.setBackground(new Color (50, 21, 152));
        perv_page.addActionListener(this);
        add(perv_page);
             // frame funtions
             setLayout(null);
             getContentPane().setBackground(new Color(255, 255, 255));
             setSize(1100, 800);
             setLocation(300, 100);
             setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             setVisible(true);
         }
         public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == perv_page) {
             new Introduction();
            setVisible(false);
        }
        else if (ae.getSource() == next_page) {
            new Instructions();
            setVisible(false);


        }
         }
    public static void main(String [] args){
        new Login();

         }
}
