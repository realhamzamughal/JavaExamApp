package Numl_Entrance_test;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class score extends JFrame implements ActionListener {
ImageIcon icon;
    ImageIcon i1;
    JButton submit;
    JLabel image;
    score(int score) {
        super("NUML Entrance Test");// main frame funtion start here
        icon = new ImageIcon(getClass().getResource("numl.jpg"));
        setIconImage(icon.getImage());
        ImageIcon i1 = new ImageIcon(getClass().getResource("NUMLBS-SE.png"));
         image = new JLabel(i1);
        image.setBounds(0,0,0,0);
        image.setSize(1100,300);
        add(image);
        setSize(1200,900);
        setLocation(300,10);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);


        String htmlContent = "<html>" +
                "<h1>Thank for showing interest in <> NATIONAL UNIVERSITY OF MODERN LANGUAGES <>" +
                "<>[  RESULT ]<><>Total Marks 100<>YOUR TEST SOCRE IS ";
        String htmlContent2 = "<html>" +
                "<h1><>NOTE:  Final Result and Merit list will be displayed on our website after two weeks ";

        JLabel heading = new JLabel(htmlContent+score+htmlContent2);
        heading.setBounds(140, 200, 600, 600);
        heading.setFont(new Font("Times New Roman", Font.PLAIN, 24));
        add(heading);

        JLabel lblscore = new JLabel("Your score is "+score);
        lblscore.setBounds(350, 200, 300, 30);
        lblscore.setFont(new Font("Tahoma", Font.PLAIN, 26));
        add(lblscore);

         submit = new JButton("EXIT");
        submit.setBounds(900, 700, 120, 50);
        submit.setBackground(new Color(30, 144, 255));
        submit.setForeground(Color.WHITE);
        submit.addActionListener(this);
        add(submit);

        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if(ae.getSource()== submit){
            setVisible(false);
            System.exit(0);
        }
    }

    public static void main(String[] args) {
        new score(0);
    }
}