package Numl_Entrance_test;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Instructions extends JFrame implements ActionListener {
    ImageIcon icon;
    ImageIcon icon_6;
    JLabel   intruct;
    JButton perv_page1;
    JButton next_page1;
    JLabel htmlLabel;
    public Instructions() {
        super("NUML Entrance Test");// main frame funtion start here
        icon = new ImageIcon(getClass().getResource("numl.jpg"));
        setIconImage(icon.getImage());
        // instruction image
        icon_6 = new ImageIcon(getClass().getResource("instructions.png"));
        intruct = new JLabel(icon_6);
        intruct.setFont(new Font("Arial",Font.BOLD,24));
        intruct.setBounds(50,0,1100,100);
        intruct.setSize(1000,100);
        add(intruct);
       // next and back button
        // button
        next_page1 = new JButton("START");
        next_page1.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        next_page1.setBounds(900, 660, 100, 50);
        next_page1.setForeground(new Color (255, 255, 255));
        next_page1.setBackground(new Color (50, 21, 152));
        next_page1.addActionListener(this);
        add(next_page1);

        // previous page
        perv_page1 = new JButton("BACK");
        perv_page1.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        perv_page1.setBounds(70, 665, 100, 50);
        perv_page1.setForeground(new Color (255, 255, 255));
        perv_page1.setBackground(new Color (50, 21, 152));
        perv_page1.addActionListener(this);
        add(perv_page1);
      // instructions
        String htmlContent = "<html>" +
                "<h1>NUML Entrance Test Instructions</h1>" +
                "<ol>" +
                "<li>Read all the questions carefully before answering.</li>" +
                "<li>Manage your time wisely. There is a time limit for each section. Keep track of the time allocated for each section.</li>" +
                "<li>Double-check your answers if you have time remaining. Review flagged questions if unsure.</li>" +
                "<li>Do not leave any question unanswered. There is no negative marking, so attempt every question.</li>" +
                "<li>Keep an eye on the timer. It is located at the top of the screen. Ensure you complete each section within the allotted time.</li>" +
                "<li>Ensure that you select the correct answer before moving to the next question. Confirm your choice.</li>" +
                "<li>Do not use any electronic devices or cheat sheets. Any form of cheating will result in disqualification.</li>" +
                "<li>Follow the instructions given by the invigilators. Raise your hand if you have any questions during the test.</li>" +
                "<li>Use the rough sheets provided for calculations and note-taking. Submit all rough sheets at the end of the test.</li>" +
                "<li>Submit your test before the time runs out. Ensure all answers are saved before submission.</li>" +
                "<li>Stay calm and focused throughout the test. Take deep breaths if you feel anxious.</li>" +
                "<li>Ensure you have the necessary stationery, including pens, pencils, and an eraser.</li>" +
               "<li>Maintain silence in the test center. Any disturbance may lead to your disqualification.</li>" +
                "<li>In case of any technical issues, immediately inform the invigilator. Do not attempt to fix the issue yourself.</li>" +
                "<li>Read the test instructions on the screen carefully before beginning each section.</li>" +
                "</ol>" +
                "</html>";
         htmlLabel = new JLabel(htmlContent);
        htmlLabel.setFont(new Font("Arial",Font.BOLD,20));
        htmlLabel.setBounds(50,30,1100,700);
        htmlLabel.setSize(1100,700);

           add(htmlLabel);


        setLayout(null);
        getContentPane().setBackground(new Color(255,255,255));
        setSize(1200,800);
        setLocation(300,10);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }
     public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== perv_page1){
            setVisible(false);
            new Login();
        }
        else if(ae.getSource() == next_page1){
        setVisible(false);
            new Test_questions();
        }
     }
    public static void main(String [] args){
     new Instructions();
    }
}