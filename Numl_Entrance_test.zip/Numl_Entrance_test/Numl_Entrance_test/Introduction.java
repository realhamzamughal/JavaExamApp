package Numl_Entrance_test;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class Introduction extends JFrame implements ActionListener {
ImageIcon icon;
ImageIcon icon_1;
JLabel Numl_logo;
JLabel Numl_title;
JLabel Numl_entrance;
JLabel Numl_wel;
JList<String> product_owner;
ImageIcon icon_2;
JButton next_page;
JButton perv_page;

    public Introduction() {
     super("NUML Entrance Test");// main frame funtion start here

      icon = new ImageIcon(getClass().getResource("numl.jpg"));
        setIconImage(icon.getImage());

      // numl logo on frame
        icon_1 = new ImageIcon(getClass().getResource("numl.jpg"));
        Numl_logo = new JLabel(icon_1);
      Numl_logo.setBounds(5,5,90,80);
      Numl_logo.setSize(400,400);
      add(Numl_logo);

      // label for numl university title
        Numl_title = new JLabel("NATIONAL UNIVERSITY OF MODERN LANGUAGES");
        Numl_title.setFont(new Font("Arial",Font.BOLD,24));
        Numl_title.setBounds(350,160,180,100);
        Numl_title.setSize(600,100);
        add(Numl_title);

      // label for welcome
        icon_2 = new ImageIcon(getClass().getResource("wel2.png"));
        Numl_wel = new JLabel(icon_2);
        Numl_wel.setBounds(350,250,90,80);
        Numl_wel.setSize(400,300);
        add(Numl_wel);

      // label
        Numl_entrance = new JLabel("NUML ENTRANCE TEST");
        Numl_entrance.setFont(new Font("SansSerif",Font.BOLD,40));
        Numl_entrance.setForeground(new Color(245,120,40));
        Numl_entrance.setBounds(320,500,180,100);
        Numl_entrance.setSize(600,100);
        add(Numl_entrance);

      // button to next page from intro
        next_page = new JButton("NEXT");
        next_page.setFont(new Font("Comic Sans MS",Font.PLAIN,15));
        next_page.setBounds(850, 650, 100, 50);
        next_page.setForeground(new Color (255, 255, 255));
        next_page.setBackground(new Color (50, 21, 152));
        next_page.addActionListener(this);
        add(next_page);

        // label for group members
        String[] list={"Developed by;","","Syeda Sara Amjad","Laiba","Hamza Mughal","Kumail abbas","Zain Ali" };
        product_owner= new JList<String>(list);
        setSize(280,356);
        product_owner.setBounds(80, 540, 180, 420);
        product_owner.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        add(product_owner);
        // Frame functions
      setLayout(null);
      getContentPane().setBackground(new Color(255,255,255));
      setSize(1100,800);
      setLocation(300,10);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
             setVisible(true);

    }
public void actionPerformed(ActionEvent ae){
        if (ae.getSource() == next_page){
            new Login();
            setVisible(false);
                    }
        else {


        }
}
    public static void main(String [] args){
        new Introduction();


    }
}
